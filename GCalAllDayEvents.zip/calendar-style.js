console.log('Extension script loaded.');

function extractDates(text) {
    const months = {
        "January": 1,
        "February": 2,
        "March": 3,
        "April": 4,
        "May": 5,
        "June": 6,
        "July": 7,
        "August": 8,
        "September": 9,
        "October": 10,
        "November": 11,
        "December": 12
    };

    const dateRegexes = [
        /(\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\b) (\d+)/, // Month Day
        /(\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\b) (\d+) – (\d+)/, // Month Day - Day
        /(\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\b) (\d+) – (\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\b) (\d+)/ // Month Day - Month Day
    ];

    const dates = [];

    for (const regex of dateRegexes) {
        const matches = text.match(regex);
        if (matches) {
            if (matches.length === 3) { // Month Day
                const month = matches[1];
                const day = parseInt(matches[2]);
                if (months.hasOwnProperty(month) && !isNaN(day)) {
                    dates.push(formatDate(new Date(new Date().getFullYear(), months[month] - 1, day)));
                }
            } else if (matches.length === 4) { // Month Day - Day
                const startMonth = matches[1];
                const startDay = parseInt(matches[2]);
                const endDay = parseInt(matches[3]);
                if (months.hasOwnProperty(startMonth) && !isNaN(startDay) && !isNaN(endDay)) {
                    for (let day = startDay; day <= endDay; day++) {
                        dates.push(formatDate(new Date(new Date().getFullYear(), months[startMonth] - 1, day)));
                    }
                }
            } else if (matches.length === 5) { // Month Day - Month Day
                const startMonth = matches[1];
                const startDay = parseInt(matches[2]);
                const endMonth = matches[3];
                const endDay = parseInt(matches[4]);
                if (months.hasOwnProperty(startMonth) && months.hasOwnProperty(endMonth) && !isNaN(startDay) && !isNaN(endDay)) {
                    const startDate = new Date(new Date().getFullYear(), months[startMonth] - 1, startDay);
                    const endDate = new Date(new Date().getFullYear(), months[endMonth] - 1, endDay);
                    let currentDate = new Date(startDate);
                    while (currentDate <= endDate) {
                        dates.push(formatDate(new Date(currentDate)));
                        currentDate.setDate(currentDate.getDate() + 1);
                    }
                }
            }
        }
    }

    return dates;
}

function formatDate(date) {
    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];
    return monthNames[date.getMonth()] + " " + date.getDate();
}

function washOutColor(rgb, washOutPercentage) {
    const [r, g, b] = rgb.match(/\d+/g).map(Number); // Extract RGB components from the input color

    // Ensure washOutPercentage is between 0 and 100
    const whiteWeight = Math.min(Math.max(washOutPercentage, 0), 100) / 100;
    const colorWeight = 1 - whiteWeight;

    // Calculate the "washed out" color by blending the input color with white based on the specified percentage
    const washedR = (r * colorWeight + 255 * whiteWeight);
    const washedG = (g * colorWeight + 255 * whiteWeight);
    const washedB = (b * colorWeight + 255 * whiteWeight);

    return `rgb(${Math.round(washedR)}, ${Math.round(washedG)}, ${Math.round(washedB)})`;
}



const modifyCalendar = function() {
    console.log('Attempting to modify the calendar...');
    const allDayEvents = document.querySelectorAll('.QGRmIf');
    const importantDates = new Map()

    allDayEvents.forEach(event => {
        document.querySelectorAll('.BiKU4b').forEach(dayColumn => dayColumn.style.backgroundColor = '');

        const eventText = event.querySelector('.ynRLnc').textContent;
        const parts = eventText.split(',').map(part => part.trim());

        // Extract the name and date
        const eventName = parts[1];

        const eventDates = extractDates(parts[4]);

        if (eventName && eventName.startsWith('!')) {
            // Check if we successfully extracted a date
            if (eventDates.length > 0) {
                console.log(`Event dates extracted: ${eventDates.join(', ')}`);
                
                // Retrieve the background color directly from the style property
                const bgColor = event.style.backgroundColor;

                // Wash out the color
                const pastelColor = washOutColor(bgColor, 60);

                // Now, find the corresponding day column by the date
                eventDates.forEach(eventDate => importantDates.set(eventDate, pastelColor));
            } else {
                console.log('Could not extract the event dates.');
            }
        }
    });

    importantDates.forEach(function(color, date) {
        console.log(`important dates: ${date} - ${color}`);
        document.querySelectorAll('.BiKU4b').forEach(dayColumn => {
            const header = dayColumn.querySelector('h2.ynRLnc');
            if (header && header.textContent.includes(date)) {
                if (color === "none") dayColumn.style.backgroundColor = '';
                else dayColumn.style.backgroundColor = color;
            }
        });
    });
};




// MutationObserver setup remains the same

const observer = new MutationObserver(() => {
    console.log('Detected changes in the DOM.');
    modifyCalendar();
});

observer.observe(document.body, { childList: true, subtree: true });

console.log('MutationObserver setup complete.');